﻿默认访问地址: http://localhost:8080/ssh_website
后台访问地址: http://localhost:8080/ssh_website/admin.jsp
默认后台用户: 用户名:1/密码:1


后端框架: struts2.5 + spring4.3 + hibernate5.2
前端框架: jquery + slideBox(图片轮播)