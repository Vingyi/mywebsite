package com.dao;

import org.springframework.stereotype.Repository;

import com.entity.Company;

@Repository//注册dao层bean等同于@Component
public class CompanyDao extends BaseDao{
		
	//获取公司信息
	public Company getCompany(){
		return getSession().createQuery("from Company", Company.class).uniqueResult();
	}

}
