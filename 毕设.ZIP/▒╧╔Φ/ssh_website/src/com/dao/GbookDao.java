package com.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.entity.Gbook;

@Repository//注册dao曾bean等同于@Component
public class GbookDao extends BaseDao {

	//分页查询部分留言//先排序再分页
	public List<Gbook> getPartGbook(int begin, int rows) {
		return getSession().createQuery("from Gbook order by id desc", Gbook.class)
				.setFirstResult(begin).setMaxResults(rows).list();
	}
	
	//获取所以留言
	public List<Gbook> getAllGbook() {
		return getSession().createQuery("from Gbook", Gbook.class).list();
	}

}
