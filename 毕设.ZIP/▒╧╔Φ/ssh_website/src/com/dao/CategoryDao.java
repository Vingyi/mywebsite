package com.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.entity.Category;

@Repository//注册dao曾bean等同于@Component
public class CategoryDao extends BaseDao{
	
	//获取全部产品类别(默认按序号排列)
	public List<Category> getCategoryList() {
		return getSession().createQuery("from Category order by id desc", Category.class).list();
	}
	
	//分页获取类目
	public List<Category> getCategoryList(String sortname, String sortorder, int begin, int rows) {
		return getSession().createQuery("from Category order by "+sortname+" "+sortorder, Category.class)
					.setFirstResult(begin).setMaxResults(rows).list();
	}
	
}
