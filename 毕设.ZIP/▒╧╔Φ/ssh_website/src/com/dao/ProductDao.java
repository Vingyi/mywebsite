package com.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.entity.Product;

@Repository//注册dao曾bean等同于@Component
public class ProductDao extends BaseDao {
	

	//获取首页展示的产品
	public List<Product> getShowProducts(int rows) {
		return getSession().createQuery("from Product where shown=1 order by id desc", Product.class)
				.setMaxResults(rows).list();
	}
	
	//获取所以产品
	public List<Product> getAllProducts() {
		return getSession().createQuery("from Product", Product.class).list();
	}
	
	//获取某类别所以产品
	public List<Product> getAllProducts(int type) {
		return getSession().createQuery("from Product where category_id=:type", Product.class)
				.setParameter("type", type).list();
	}

	//随机获取产品信息
	public List<Product> getProductList(int begin, int rows) {
		return getSession().createQuery("from Product order by id desc", Product.class)
				.setFirstResult(begin).setMaxResults(rows).list();
	}
	
	//随机获取部分产品信息
	public List<Product> getPartProductRandom(int begin, int rows) {
		return getSession().createQuery("from Product order by rand()", Product.class)
				.setFirstResult(begin).setMaxResults(rows).list();
	}
	
	//按产品类型获取部分产品
	public List<Product> getPartProduct(int begin, int rows, int type) {
		return getSession().createQuery("from Product where category_id=:type order by id desc", Product.class)
				.setParameter("type", type).setFirstResult(begin).setMaxResults(rows).list();
	}

	//通过id查找产品
	public Product getProduct(int id) {
		return select(Product.class, id);
	}

}
