package com.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.entity.News;

@Repository//注册dao曾bean等同于@Component
public class NewsDao extends BaseDao {

	//分页查询部分新闻//先排序再分页
	public List<News> getNewsList(int begin, int rows) {
		return getSession().createQuery("from News order by id desc", News.class)
				.setFirstResult(begin).setMaxResults(rows).list();
	}
	
	//获取所以新闻(按时间排序)
	public List<News> getAllNews() {
		return getSession().createQuery("from News order by time desc", News.class).list();
	}

	//通过id查找单个新闻
	public News getNews(int id) {
		return select(News.class, id);
	}

}
